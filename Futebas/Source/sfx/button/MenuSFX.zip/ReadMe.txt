Dearest End-User,

Is there any point in licensing creative work in the internet age?  Does anything really belong to anyone?  I don't think so, I'm just glad you thought my work was worth paying for, and since I'm going to be doing this kind of work probably for the remainder of my days on Earth, I might as well try and turn this into some sort of sustainable venture.  So use these sounds how you see fit.  I HIGHLY encourage you to adjust, bit-reduce, contort, distort, enhance, filter, gnarl, mangle, and then let me know what you come up with (hitrison@gmail.com -OR- kevinfowler@mail.com).

Go Make Something,

-Kevin Fowler